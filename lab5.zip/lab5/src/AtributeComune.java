public abstract class AtributeComune {
    protected int numar;
    protected String titlu;

    public int getNumar(){
        return numar;
    }
    public void setNumar(int val){
        numar = val;
    }

    public String getTitlu(){
        return titlu;
    }
    public void setTitlu(String titlu) {
        this.titlu = titlu;
    }

}
