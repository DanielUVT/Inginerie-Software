import java.util.ArrayList;
import java.util.List;

public class Parti  extends AtributeComune{
    private List<Capitole> capitole = new ArrayList<>();

    public void adaugareCapitole(Capitole capitol){
        capitole.add(capitol);
    }
    public List<Capitole> getCapitole(){
        return capitole;
    }

    public Parti(int numar, String titlu){
        this.numar = numar;
        this.titlu = titlu;
    }
}
