public class Main {
    public static void main(String[] args) {
        Carte HarryPotter = new Carte("J.K. Rowling",
                                "10/09/2001",
                                "123-1234-12345");
        Parti philosophersStone = new Parti(362, "Philosopher's Stone");
        Capitole capitol1 = new Capitole("uidwhauidhauiwh", 192, "One");
        Capitole capitol2 = new Capitole("dwad adwad daw", 170, "Two");
        Sectiuni sec11 = new Sectiuni(90, "Nam idee");
        Sectiuni sec12 = new Sectiuni(102, "Nam idee 2");

        Sectiuni sec21 = new Sectiuni(120, "Nush1");
        Sectiuni sec22 = new Sectiuni(50, "Nush2");
        HarryPotter.adaugareParti(philosophersStone);
        philosophersStone.adaugareCapitole(capitol1);
        philosophersStone.adaugareCapitole(capitol2);
        capitol1.adaugareSectiuni(sec11);
        capitol1.adaugareSectiuni(sec12);
        capitol2.adaugareSectiuni(sec12);
        capitol2.adaugareSectiuni(sec22);


        System.out.println("Carte: Harry Potter, editor: " + HarryPotter.getEditor() + " Data publicare: " + HarryPotter.getData() +
                " ISBN: " + HarryPotter.getISBN());
        for(int i = 0; i < HarryPotter.getParti().size(); i++){
            Parti x = HarryPotter.getParti().get(i);
            System.out.println("Parte: " + x.getTitlu() + ", pagini: " + x.getNumar());
            for (int j = 0; j < x.getCapitole().size(); j++){
                Capitole y = x.getCapitole().get(j);
                System.out.println("    Capitol: " + y.getTitlu() + ", pagini: " + y.getNumar() + ", rezumat: " + y.getRezumat());
                for (int h = 0; h < y.getSectiuni().size(); h++){
                    Sectiuni z = y.getSectiuni().get(h);
                    System.out.println("        Sectiunea: " + z.getTitlu() + ", pagini: " + z.getNumar());

                }
            }

        }


    }
}
