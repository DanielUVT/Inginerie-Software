public class Sectiuni extends AtributeComune{
    public Sectiuni(int numar, String titlu){
        this.titlu = titlu;
        this.numar = numar;
    }
}
