import java.util.List;
import java.util.ArrayList;

public class Capitole extends AtributeComune{
    private String rezumat;
    private List<Sectiuni> sectiuni = new ArrayList<>();


    public String getRezumat(){
        return rezumat;
    }
    public void setRezumat(String rezumat){
        this.rezumat = rezumat;
    }
    public void adaugareSectiuni(Sectiuni sectiune){
        sectiuni.add(sectiune);
    }
    public List<Sectiuni> getSectiuni(){
        return sectiuni;
    }
    public Capitole(String rezumat, int numar, String titlu){
        this.rezumat = rezumat;
        this.titlu = titlu;
        this.numar = numar;
    }
}
