import java.util.ArrayList;
import java.util.List;

public class Carte {
    private String editor;
    private String dataPublicare;
    private String ISBN;
    private List<Parti> parti = new ArrayList<>();

    public Carte(String editor, String dataPublicare, String ISBN){
        this.dataPublicare = dataPublicare;
        this.editor = editor;
        this.ISBN = ISBN;
    }

    public void adaugareParti(Parti parte){
        parti.add(parte);
    }
    public List<Parti> getParti(){
        return parti;
    }

    public String getEditor(){
        return editor;
    }
    public void setEditor(String editor){
        this.editor = editor;
    }

    public String getData(){
        return dataPublicare;
    }
    public void setData(String dataPublicare){
        this.dataPublicare = Carte.this.dataPublicare;
    }

    public String getISBN(){
        return ISBN;
    }
    public void setISBN(String ISBN){
        this.ISBN = ISBN;
    }
}